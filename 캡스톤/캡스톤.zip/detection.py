import cv2
import numpy as np

def signDetectCamera(video) :
    while True :
        s, frame = video.read()
        frameBlur = cv2.GaussianBlur(frame, (5,5), 0)
        frameYuv = cv2.cvtColor(frameBlur, cv2.COLOR_BGR2YUV)
        frameY, frameU, frameV = cv2.split(frameYuv)
        cannyU = cv2.Canny(frameU, 150, 255, apertureSize=3)
        cannyV = cv2.Canny(frameV, 150, 200, apertureSize=3)
        contoursU, _ = cv2.findContours(cannyU, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contoursV, _ = cv2.findContours(cannyV, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
        for cnt in contoursV :
            (x, y, w, h) = cv2.boundingRect(cnt)
            cv2.rectangle(frame, (x,y), (x+w, y+h),(0,0,255),1)         
            
        cv2.imshow('origin', frame)
        cv2.imshow('canny', cannyV)

        if cv2.waitKey(30) & 0xff == 27 :
            break;

def signDetectVideo(video) :
    while True :
        if(video.get(cv2.CAP_PROP_POS_FRAMES) == video.get(cv2.CAP_PROP_FRAME_COUNT)):
            video.open("./road.mp4")

        s, frame = video.read()
        frame = cv2.resize(frame, (640,360))
        frameBlur = cv2.GaussianBlur(frame, (5,5), 0)
        frameYuv = cv2.cvtColor(frameBlur, cv2.COLOR_BGR2YUV)
        frameY, frameU, frameV = cv2.split(frameYuv)
        cannyU = cv2.Canny(frameU, 150, 255, apertureSize=3)
        cannyV = cv2.Canny(frameV, 50, 200, apertureSize=3)
        contoursU, _ = cv2.findContours(cannyU, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contoursV, _ = cv2.findContours(cannyV, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
        for cnt in contoursV :
            (x, y, w, h) = cv2.boundingRect(cnt)
            cv2.rectangle(frame, (x,y), (x+w, y+h),(0,0,255),2)         
            
        cv2.imshow('origin', frame)
        cv2.imshow('canny', cannyV)

        if cv2.waitKey(int(video.get(cv2.CAP_PROP_FPS))) & 0xff == 27 :
            break;        

cam = cv2.VideoCapture(1)
vid = cv2.VideoCapture('./road.mp4')
if cam.isOpened() :
    cam.set(3, 640)
    cam.set(4, 360)

    signDetectCamera(cam)

    cam.release()
elif vid.isOpened() :
    signDetectVideo(vid)

    vid.release()
else :
    print("NoVideo")

cv2.destroyAllWindows()
